library( ggplot2 )
library( gridExtra )
library( grid )
library( ggpubr )
##### Result 1. nsnp = 100; nconf = 10 #####
mydata1 <- data.frame( 
  data = c( 
    0.808, 0.166, 0.304, 0.470, 0.086, 0.002, 0.002, 0.004, 0.004,
    0.984, 0.782, 0.976, 0.974, 0.338, 0.672, 0.688, 0.726, 0.752,
    1.000, 1.000, 1.000, 1.000, 0.604, 0.908, 0.922, 0.974, 0.986 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 2. nsnp = 100; nconf = 20 #####
mydata2 <- data.frame( 
  data = c( 
    0.832, 0.156, 0.270, 0.454, 0.100, 0.004, 0.004, 0.004, 0.004,
    0.974, 0.810, 0.978, 0.966, 0.334, 0.680, 0.684, 0.735, 0.774,
    1.000, 1.000, 1.000, 1.000, 0.596, 0.936, 0.942, 0.990, 0.992 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)


##### Result 3. nsnp = 100; nconf = 50 #####
mydata3 <- data.frame( 
  data = c( 
    0.862, 0.172, 0.280, 0.438, 0.078, 0.006, 0.006, 0.006, 0.006,
    0.972, 0.800, 0.974, 0.980, 0.364, 0.694, 0.706, 0.758, 0.796,
    1.000, 1.000, 1.000, 1.000, 0.602, 0.920, 0.938, 0.972, 0.988 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 4. nsnp = 200; nconf = 10 #####
mydata4 <- data.frame( 
  data = c( 
    0.938, 0.180, 0.348, 0.436, 0.002, 0.002, 0.002, 0.002, 0.002,
    0.998, 0.948, 1.000, 0.994, 0.072, 0.818, 0.838, 0.880, 0.916,
    1.000, 1.000, 1.000, 1.000, 0.226, 0.980, 0.984, 0.994, 0.998 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 5. nsnp = 200; nconf = 20 #####
mydata5 <- data.frame( 
  data = c( 
    0.926, 0.210, 0.330, 0.398, 0.002, 0.002, 0.002, 0.002, 0.002,
    0.994, 0.952, 1.000, 0.998, 0.042, 0.786, 0.804, 0.852, 0.890,
    1.000, 1.000, 1.000, 1.000, 0.242, 0.976, 0.982, 0.982, 0.998 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 6. nsnp = 200; nconf = 50 #####
mydata6 <- data.frame( 
  data = c( 
    0.992, 0.218, 0.346, 0.368, 0.002, 0.002, 0.002, 0.002, 0.002,
    1.000, 0.960, 1.000, 1.000, 0.070, 0.810, 0.812, 0.864, 0.904,
    1.000, 1.000, 1.000, 1.000, 0.258, 0.970, 0.976, 0.988, 0.994 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)


##### Result 7. nsnp = 500; nconf = 10 #####
mydata7 <- data.frame( 
  data = c(
    0.996, 0.192, 0.374, 0.338, 0.002, 0.002, 0.002, 0.002, 0.002,
    1.000, 0.960, 1.000, 1.000, 0.002, 0.876, 0.886, 0.968, 0.986,
    1.000, 1.000, 1.000, 1.000, 0.004, 0.998, 0.998, 1.000, 1.000 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 8. nsnp = 500; nconf = 20 #####
mydata8 <- data.frame( 
  data = c(
    0.990, 0.194, 0.364, 0.342, 0.002, 0.002, 0.002, 0.002, 0.002,
    1.000, 0.972, 1.000, 1.000, 0.004, 0.880, 0.884, 0.964, 0.986,
    1.000, 1.000, 1.000, 1.000, 0.006, 0.998, 0.998, 1.000, 1.000 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### nsnp = 500; nconf = 50 #####
mydata9 <- data.frame( 
  data = c(
    0.986, 0.204, 0.372, 0.302, 0.002, 0.004, 0.004, 0.004, 0.004,
    1.000, 0.976, 1.000, 1.000, 0.006, 0.878, 0.884, 0.964, 0.980,
    1.000, 1.000, 1.000, 1.000, 0.008, 0.996, 0.998, 1.000, 1.000 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)
# ##### nsnp = 1000; nconf = 10 #####
# 
# ##### nsnp = 1000; nconf = 20 #####
# 
# ##### nsnp = 1000; nconf = 50 #####


p1 <- ggplot( mydata1, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = 'Type I error / Power', title = 'nSNP = 100; nConf = 10' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.3,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p2 <- ggplot( mydata2, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nSNP = 100; nConf = 20' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p3 <- ggplot( mydata3, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nSNP = 100; nConf = 50' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p4 <- ggplot( mydata4, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = 'Type I error / Power', title = 'nSNP = 200; nConf = 10' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.3,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )
p5 <- ggplot( mydata5, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nSNP = 200; nConf = 20' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )
p6 <- ggplot( mydata6, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nSNP = 200; nConf = 50' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p7 <- ggplot( mydata7, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = expression( h[gamma]^2 ),
        y = NULL, title = 'nSNP = 500; nConf = 10' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p8 <- ggplot( mydata7, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = expression( h[gamma]^2 ), y = NULL, title = 'nSNP = 500; nConf = 20' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p9 <- ggplot( mydata7, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = expression( h[gamma]^2 ), y = NULL, title = 'nSNP = 500; nConf = 50' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

combined <- ggarrange( p1, p2, p3, p4, p5, p6, p7, p8, p9, align = 'hv', common.legend = T, legend = 'bottom' )
grid.newpage( ); grid.draw( combined )
# # ggsave( '/Volumes/Hide in lab/Yu Cheng/博士课题/Multi-tissue MR/Results/Simulation/nSNP_nConf/TypeIerror.pdf', plot = combined, width = 12, height = 14 )
