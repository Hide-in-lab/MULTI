library( ggplot2 )
library( gridExtra )
library( grid )
library( ggpubr )
##### Result 1. n_X = 2 #####
mydata1 <- data.frame( 
  data = c( 
    0.802, 0.188, 0.274, 0.458, 0.074, 0.002, 0.002, 0.002, 0.002,
    0.972, 0.826, 0.986, 0.976, 0.374, 0.664, 0.690, 0.716, 0.758,
    1.000, 1.000, 1.000, 1.000, 0.626, 0.938, 0.952, 0.976, 0.992 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 2. n_X = 5 #####
mydata2 <- data.frame( 
  data = c( 
    0.804, 0.164, 0.300, 0.438, 0.094, 0.004, 0.004, 0.004, 0.004,
    0.968, 0.806, 0.968, 0.968, 0.370, 0.670, 0.718, 0.792, 0.864,
    1.000, 1.000, 1.000, 1.000, 0.590, 0.942, 0.956, 0.994, 0.996 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 3. n_X = 10 #####
mydata3 <- data.frame( 
  data = c( 
    0.846, 0.156, 0.290, 0.472, 0.082, 0.002, 0.002, 0.002, 0.004,
    0.988, 0.790, 0.988, 0.980, 0.358, 0.658, 0.754, 0.858, 0.922,
    1.000, 1.000, 1.000, 1.000, 0.608, 0.950, 0.962, 0.994, 0.998),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 4. n_X = 15 #####
mydata4 <- data.frame( 
  data = c( 
    0.812, 0.146, 0.276, 0.446, 0.068, 0.002, 0.002, 0.002, 0.002,
    0.974, 0.802, 0.978, 0.960, 0.344, 0.640, 0.654, 0.830, 0.892,
    1.000, 1.000, 1.000, 1.000, 0.594, 0.916, 0.952, 0.994, 0.996 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 5. n_X = 20 #####
mydata5 <- data.frame( 
  data = c( 
    0.814, 0.202, 0.306, 0.470, 0.094, 0.004, 0.004, 0.006, 0.006,
    0.966, 0.766, 0.956, 0.968, 0.352, 0.644, 0.646, 0.876, 0.898,
    1.000, 1.000, 1.000, 1.000, 0.624, 0.916, 0.940, 0.924, 0.910 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 6. n_X = 30 #####
mydata6 <- data.frame( 
  data = c( 
    0.820, 0.222, 0.310, 0.488, 0.124, 0.004, 0.004, 0.006, 0.006,
    0.968, 0.806, 0.946, 0.962, 0.356, 0.654, 0.666, 0.880, 0.898,
    1.000, 1.000, 1.000, 1.000, 0.644, 0.920, 0.940, 0.964, 0.990  ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

p1 <- ggplot( mydata1, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = 'Type I error / Power', title = 'K = 2' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.3,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p2 <- ggplot( mydata2, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'K = 5' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p3 <- ggplot( mydata3, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'K = 10' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p4 <- ggplot( mydata4, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = expression( h[gamma]^2 ), y = 'Type I error / Power', title = 'K = 15' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.3,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )
p5 <- ggplot( mydata5, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = expression( h[gamma]^2 ), y = NULL, title = 'K = 20' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )
p6 <- ggplot( mydata6, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = expression( h[gamma]^2 ), y = NULL, title = 'K = 30' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

combined <- ggarrange( p1, p2, p3, p4, p5, p6, align = 'hv', common.legend = T, legend = 'bottom' )
grid.newpage( ); grid.draw( combined )
# # ggsave( '/Volumes/Hide in lab/Yu Cheng/博士课题/Multi-tissue MR/Results/Simulation/n_X/TypeIerror.pdf', plot = combined, width = 14, height = 10 )
