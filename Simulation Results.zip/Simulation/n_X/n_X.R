#####----- Load R packages -----#####
library( MULTI )
library( MASS )
library( MendelianRandomization )
library( MCMCpack )
library( dlm )
library( distr )
library( progress )
library( dplyr )
library( parallel )

parameters <- data.frame( 
  LD_TBD = rep( c( 0, 0.2, 0.5, 0.7, 0.9 ), each = 500*3 ),
  h2_gamma_TBD = rep( rep( c( 0, 10^-2, 10^-1 ), each = 500 ), 5 ),
  seed = 1:500 )

sim_res <- list( )
sim_res <- mclapply( 1:nrow( parameters ), function( i ){
  
  # i <- 2501; parameters[i, ]
  LD   <- parameters[ i, 1 ]  ############ Check Point 2
  h2_gamma  <- parameters[ i, 2 ]
  seed <- parameters[ i, 3]
  set.seed( seed )
  
  #####----- Main Function -----#####
  h2_delta1  <- h2_gamma*4/5; h2_kappax1 <- h2_gamma/5
  n_X <- 5
  beta_true <- ifelse( h2_gamma == 0, 0, 0.01 )
  
  #####----- Customed functions -----#####
  #---- 1. Generate Continuous Genotype Matrix -----#
  genotype_continuous <- function( sample_size, nsnp, r_LD ){
    # sample_size <- 10000; nsnp <- 10; r_LD <- 0.2
    miu <- rep(0, nsnp)   ### Set mean variable
    Sigma <- matrix( 1:nsnp^2, ncol = nsnp )   #### Set initial covariance matrix
    for( i in 1:nsnp ){
      Sigma[i, ] <- r_LD^abs( i - (1:nsnp) )   ### Calculate the covariance matrix
    }  ### Elements for the i-th row are r^| i - n |
    return( mvrnorm( sample_size, miu, Sigma ) )
  }
  #---- 2. Convert Continuous Matrix to Factoral Matrix -----#
  genotype_to_factor  <- function( gene_matrix, minor_allel_frequency = c() ){
    MAF_cut <- function( x ){
      MAF <- runif( 1, minor_allel_frequency[1], minor_allel_frequency[2] )
      qt_aa <- MAF^2
      qt_Aa <- MAF*(2 - MAF)   ## 0___aa(MAF*MAF)___Aa(MAF*(2-MAF))___1 ##
      as.integer( cut(x, breaks = c(-Inf, quantile( x, c(qt_aa, qt_Aa) ), Inf), labels = c(0, 1, 2) ) ) - 1
    }
    G <- apply(gene_matrix, 2, MAF_cut)
    return(G)
  }
  #---- 3. Data Generating Function -----#
  data_generating <- function(
    nGTEx = 10000, nGWAS = 10000,
    nsnp = 100, nconf = 10,  ## nconf for number of confounders ##
    r_kappa = 0.2,
    r_LD = rep( 0.5, n_X ),
    h2 = list( h2_delta  = c( h2_delta1,  rep( h2_delta1  / ( n_X - 1 ), n_X - 1 ) ),
               h2_kappax = c( h2_kappax1, rep( h2_kappax1 / ( n_X - 1 ), n_X - 1 ) ),
               h2_kappay = c( 0.02, rep( 0.02 / ( n_X - 1 ), n_X - 1 ) ),
               h2_theta  = c( 0.02, rep( 0.02 / ( n_X - 1 ), n_X - 1 ) ) ),  ############ Check Point 4
    beta = rep( beta_true, n_X ) ) {
    ##### Initialize parameters #####
    nsample <- nGTEx + nGWAS
    h2_total <- sum( unlist( h2 ) )
    k_scale  <- ( sum( beta^2 ) + 1 ) / ( 1 - h2_total )
    
    delta <- rnorm( nsnp * n_X, 0, 1 )
    kappa  <- mvrnorm( nsnp * n_X, mu = c( 0, 0 ), Sigma = matrix( c( 1, r_kappa, r_kappa, 1 ), nrow = 2 ) )
    kappax <- kappa[ , 1 ]; kappay <- kappa[ , 2 ]
    theta <- rnorm( nsnp * n_X, 0, 1 )
    fai <- mvrnorm( nconf * n_X, mu = c( 0, 0 ), Sigma = matrix( c( 1, 0, 0, 1 ), nrow = 2 ) )
    faix <- fai[ , 1 ]; faiy <- fai[ , 2 ]
    G <- genotype_continuous( sample_size = nsample, nsnp = nsnp * n_X, r_LD = r_LD ) %>% 
      genotype_to_factor( ., c( 0.05, 0.5 ) )
    U <- matrix( rnorm( nsample * nconf * n_X ), ncol = nconf * n_X )
    
    G_delta <- c(  ); G_kappax <- c( )
    if( sum( h2$h2_delta ) == 0 ){
      for( i in 1:n_X ){
        G_delta_t <- G[ , ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% delta[ ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ]
        G_delta   <- c( G_delta, G_delta_t )
        G_kappax_t <- G[ ,  ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% kappax[ ( nsnp * ( i - 1) + 1 ):( nsnp*i ) ]
        G_kappax   <- c( G_kappax, G_kappax_t )
      }
    } else {
      for( i in 1:n_X ){
        G_delta_t <- G[ , ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% delta[ ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ]
        delta_t   <- delta[ ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] * sqrt( h2$h2_delta[ i ] * k_scale / beta[ i ]^2 / as.numeric( var( G_delta_t ) ) )
        G_delta_t <- G[ , ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% delta_t
        G_delta   <- c( G_delta, G_delta_t )
        G_kappax_t <- G[ ,  ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% kappax[ ( nsnp * ( i - 1) + 1 ):( nsnp*i ) ]
        kappax_t   <- kappax[ ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] * sqrt( h2$h2_kappax[ i ] * k_scale / beta[ i ]^2 / as.numeric( var( G_kappax_t ) ) )
        G_kappax_t <- G[ ,  ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% kappax_t
        G_kappax   <- c( G_kappax, G_kappax_t )
      }
    }
    
    G_kappay <- c( ); G_theta <- c( )
    if( sum( h2$h2_kappay ) == 0 ){
      G_kappay <- rep( 0, nsample * n_X )
    } else {
      for( i in 1:n_X ){
        G_kappay_t <- G[ ,  ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% kappay[ ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ]
        kappay_t   <- kappay[ ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] * sqrt( h2$h2_kappay[ i ] * k_scale / as.numeric( var( G_kappay_t ) ) )
        G_kappay_t <- G[ ,  ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% kappay_t
        G_kappay   <- c( G_kappay, G_kappay_t )
      }
    }
    
    if( sum( h2$h2_theta ) == 0 ){
      G_theta <- rep( 0, nsample * n_X )
    } else {
      for( i in 1:n_X ){
        G_theta_t <- G[ , ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% theta[ ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ]
        theta_t <- theta[ ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] * sqrt( h2$h2_theta[ i ] * k_scale / as.numeric( var( G_theta_t ) ) )
        G_theta_t <- G[ , ( nsnp * ( i - 1) + 1 ):( nsnp * i ) ] %*% theta_t
        G_theta <- c( G_theta, G_theta_t )
      }
    }
    
    U_faix <- c( ); U_faiy <- c( )
    for( i in 1:n_X ){
      U_faix_t <- U[ , ( nconf * ( i - 1) + 1 ):( nconf * i ) ] %*% faix[ ( nconf * ( i - 1) + 1 ):( nconf * i ) ]
      U_faiy_t <- U[ , ( nconf * ( i - 1) + 1 ):( nconf * i ) ] %*% faiy[ ( nconf * ( i - 1) + 1 ):( nconf * i ) ]
      U_faix_t <- U_faix_t / as.numeric( sqrt( var( U_faix_t ) / 0.8 ) )
      U_faiy_t <- U_faiy_t / as.numeric( sqrt( var( U_faiy_t ) / 0.05 ) )
      U_faix <- c( U_faix, U_faix_t ); U_faiy <- c( U_faiy, U_faiy_t )
    }
    
    X <- G_delta + G_kappax + U_faix + rnorm( nsample * n_X ) * sqrt( 0.2 )
    X <- matrix( X, ncol = n_X )
    G_kappay <- matrix( G_kappay, ncol = n_X )
    G_theta  <- matrix( G_theta,  ncol = n_X )
    U_faiy   <- matrix( U_faiy,   ncol = n_X )
    Y <- X %*% beta + G_kappay %*% rep( 1, n_X ) + G_theta %*% rep( 1, n_X ) + U_faiy %*% rep( 1, n_X ) + rnorm( nsample ) * as.numeric( sqrt( 1 - 0.05 * n_X ) )
    
    # var( beta[1]*G_delta[1:20000] ) / var( Y ); var( beta[1]*G_kappax[1:20000] ) / var( Y );
    # var( G_kappay[1:20000] ) / var( Y ); var( G_theta[1:20000] ) / var( Y );
    # var( beta[2]*G_delta[20001:40000] ) / var( Y ); var( beta[2]*G_kappax[20001:40000] ) / var( Y );
    # var( G_kappay[20001:40000] ) / var( Y ); var( G_theta[20001:40000] ) / var( Y );
    # var( beta[3]*G_delta[40001:60000] ) / var( Y ); var( beta[3]*G_kappax[40001:60000] ) / var( Y );
    # var( G_kappay[40001:60000] ) / var( Y ); var( G_theta[40001:60000] ) / var( Y );
    
    ##### Linear-regression #####
    result_list <- list( )
    for( i in 1:n_X ){
      model_gamma <- lm_cpp( X[ ( 1 : nGTEx ),           i ], G[ ( 1 : nGTEx ),           ( nsnp * ( i - 1) + 1 ) : ( nsnp * i ) ] )
      model_Gamma <- lm_cpp( Y[ ( nGTEx + 1 ) : nsample ],    G[ ( nGTEx + 1 ) : nsample, ( nsnp * ( i - 1) + 1 ) : ( nsnp * i ) ] )
      mydata <- list( bx   = as.matrix( model_gamma$coef ),
                      bxse = as.matrix( model_gamma$std ),
                      by   = as.matrix( model_Gamma$coef ),
                      byse = as.matrix( model_Gamma$std ),
                      GT = G[ , ( nsnp * ( i - 1) + 1 ) : ( nsnp * i ) ],
                      R_hat = cor( G[ , ( nsnp * ( i - 1) + 1 ) : ( nsnp * i ) ] ) )
      result_list[[ paste0( 'Tissue', i ) ]] <- mydata
    }
    return( result_list )
  }
  
  mydata <- data_generating(
    nGTEx = 10000, nGWAS = 10000,
    nsnp = 100, nconf = 10,  ## nconf for number of confounders ##
    r_kappa = 0.2,
    r_LD = rep( 0.5, n_X ),
    h2 = list( h2_delta  = c( h2_delta1,  rep( h2_delta1/( n_X - 1 ), n_X - 1 ) ),
               h2_kappax = c( h2_kappax1, rep( h2_kappax1/( n_X - 1 ), n_X - 1 ) ),
               h2_kappay = c( 0.02, rep( 0.02/( n_X - 1 ), n_X - 1 ) ),
               h2_theta  = c( 0.02, rep( 0.02/( n_X - 1 ), n_X - 1 ) ) ),  ############ Check Point 4
    beta = rep( beta_true, n_X ) ) ############ Check Point 5
  
  mrinput <- mr_input( bx   = as.numeric( mydata$Tissue1$bx ),
                       bxse = as.numeric( mydata$Tissue1$bxse ),
                       by   = as.numeric( mydata$Tissue1$by ),
                       byse = as.numeric( mydata$Tissue1$byse ) )
  
  res_median <- mr_median( mrinput )
  res_mode   <- mr_mbe( mrinput )
  res_ivw    <- mr_ivw( mrinput )
  res_pivw   <- mr_pivw( mrinput )
  res_egger  <- mr_egger( mrinput )
  res_conmix <- mr_conmix( mrinput )
  res_MULTI  <- MULTI( mydata )
  HD_matrix  <- res_MULTI[[ n_X + 1 ]]
  
  tissue_similar_0.1 <- c()
  for( j in 1:length( mydata ) ){
    # j <- 1
    if( HD_matrix[ 1, j ] < 0.1 ) tissue_similar_0.1 <- c( tissue_similar_0.1, paste0( 'Tissue', j ) )
  }
  bx_new <- c()
  bxse_new <- c()
  by_new <- c()
  byse_new <- c()
  GT_new <- c()
  for( i in 1:length( tissue_similar_0.1 ) ){
    bx_new   <- rbind( bx_new,   mydata[[ tissue_similar_0.1[i] ]]$bx )
    bxse_new <- rbind( bxse_new, mydata[[ tissue_similar_0.1[i] ]]$bxse )  
    by_new   <- rbind( by_new,   mydata[[ tissue_similar_0.1[i] ]]$by )
    byse_new <- rbind( byse_new, mydata[[ tissue_similar_0.1[i] ]]$byse )
    GT_new   <- cbind( GT_new,   mydata[[ tissue_similar_0.1[i] ]]$GT )
  }
  mydata_new    <- list( bx = bx_new, bxse = bxse_new, by = by_new, byse = byse_new, R_hat = cor( GT_new ) )
  res_MULTI_0.1_final <- MULTI_single( mydata_new )
  
  tissue_similar_0.3 <- c()
  for( j in 1:length( mydata ) ){
    if( HD_matrix[ 1, j ] < 0.3 ) tissue_similar_0.3 <- c( tissue_similar_0.3, paste0( 'Tissue', j ) )
  }
  bx_new <- c()
  bxse_new <- c()
  by_new <- c()
  byse_new <- c()
  GT_new <- c()
  for( i in 1:length( tissue_similar_0.3 ) ){
    bx_new   <- rbind( bx_new,   mydata[[ tissue_similar_0.3[i] ]]$bx )
    bxse_new <- rbind( bxse_new, mydata[[ tissue_similar_0.3[i] ]]$bxse )  
    by_new   <- rbind( by_new,   mydata[[ tissue_similar_0.3[i] ]]$by )
    byse_new <- rbind( byse_new, mydata[[ tissue_similar_0.3[i] ]]$byse )
    GT_new   <- cbind( GT_new,   mydata[[ tissue_similar_0.3[i] ]]$GT )
  }
  mydata_new    <- list( bx = bx_new, bxse = bxse_new, by = by_new, byse = byse_new, R_hat = cor( GT_new ) )
  res_MULTI_0.3_final <- MULTI_single( mydata_new )
  
  tissue_similar_0.5 <- c()
  for( j in 1:length( mydata ) ){
    if( HD_matrix[ 1, j ] < 0.5 ) tissue_similar_0.5 <- c( tissue_similar_0.5, paste0( 'Tissue', j ) )
  }
  bx_new <- c()
  bxse_new <- c()
  by_new <- c()
  byse_new <- c()
  GT_new <- c()
  for( i in 1:length( tissue_similar_0.5 ) ){
    bx_new   <- rbind( bx_new,   mydata[[ tissue_similar_0.5[i] ]]$bx )
    bxse_new <- rbind( bxse_new, mydata[[ tissue_similar_0.5[i] ]]$bxse )  
    by_new   <- rbind( by_new,   mydata[[ tissue_similar_0.5[i] ]]$by )
    byse_new <- rbind( byse_new, mydata[[ tissue_similar_0.5[i] ]]$byse )
    GT_new   <- cbind( GT_new,   mydata[[ tissue_similar_0.5[i] ]]$GT )
  }
  mydata_new    <- list( bx = bx_new, bxse = bxse_new, by = by_new, byse = byse_new, R_hat = cor( GT_new ) )
  res_MULTI_0.5_final <- MULTI_single( mydata_new )
  
  e_median <- c( res_median@Estimate, res_median@CILower, res_median@CIUpper )
  e_mode   <- c( res_mode@Estimate,   res_mode@CILower,   res_mode@CIUpper )
  e_ivw    <- c( res_ivw@Estimate,  res_ivw@CILower,  res_ivw@CIUpper )
  e_pivw   <- c( res_pivw@Estimate, res_pivw@CILower, res_pivw@CIUpper )
  e_egger  <- c( res_egger@Estimate, res_egger@CILower.Est, res_egger@CIUpper.Est )
  e_conmix <- c( res_conmix@Estimate,  res_conmix@CILower, res_conmix@CIUpper )
  e_MULTI  <- c( res_MULTI[[1]]$mu_beta,
                 res_MULTI[[1]]$mu_beta - 1.96 * res_MULTI[[1]]$se_beta,
                 res_MULTI[[1]]$mu_beta + 1.96 * res_MULTI[[1]]$se_beta )
  e_MULTI_0.1 <- c( res_MULTI_0.1_final$mu_beta,
                    res_MULTI_0.1_final$mu_beta - 1.96 * res_MULTI_0.1_final$se_beta,
                    res_MULTI_0.1_final$mu_beta + 1.96 * res_MULTI_0.1_final$se_beta )
  e_MULTI_0.3 <- c( res_MULTI_0.3_final$mu_beta,
                    res_MULTI_0.3_final$mu_beta - 1.96 * res_MULTI_0.3_final$se_beta,
                    res_MULTI_0.3_final$mu_beta + 1.96 * res_MULTI_0.3_final$se_beta )
  e_MULTI_0.5 <- c( res_MULTI_0.5_final$mu_beta,
                    res_MULTI_0.5_final$mu_beta - 1.96 * res_MULTI_0.5_final$se_beta,
                    res_MULTI_0.5_final$mu_beta + 1.96 * res_MULTI_0.5_final$se_beta )
  ##### Type I error #####
  typeI_median    <- ifelse( e_median[2]    > 0 | e_median[3]    < 0, 'Reject', 'Accept' )
  typeI_mode      <- ifelse( e_mode[2]      > 0 | e_mode[3]      < 0, 'Reject', 'Accept' )
  typeI_ivw       <- ifelse( e_ivw[2]       > 0 | e_ivw[3]       < 0, 'Reject', 'Accept' )
  typeI_pivw      <- ifelse( e_pivw[2]      > 0 | e_pivw[3]      < 0, 'Reject', 'Accept' )
  typeI_egger     <- ifelse( e_egger[2]     > 0 | e_egger[3]     < 0, 'Reject', 'Accept' )
  typeI_conmix    <- ifelse( e_conmix[2]    > 0 | e_conmix[3]    < 0, 'Reject', 'Accept' )
  typeI_MULTI     <- ifelse( e_MULTI[2]     > 0 | e_MULTI[3]     < 0, 'Reject', 'Accept' )
  typeI_MULTI_0.1 <- ifelse( e_MULTI_0.1[2] > 0 | e_MULTI_0.1[3] < 0, 'Reject', 'Accept' )     
  typeI_MULTI_0.3 <- ifelse( e_MULTI_0.3[2] > 0 | e_MULTI_0.3[3] < 0, 'Reject', 'Accept' ) 
  typeI_MULTI_0.5 <- ifelse( e_MULTI_0.5[2] > 0 | e_MULTI_0.5[3] < 0, 'Reject', 'Accept' ) 
  typeIerror <- c( typeI_median, typeI_mode, typeI_ivw, typeI_pivw, typeI_egger, typeI_conmix,
                   typeI_MULTI, typeI_MULTI_0.1, typeI_MULTI_0.3, typeI_MULTI_0.5 )
  names( typeIerror ) <- c( 'Median', 'Mode', 'IVW', 'pIVW', 'Egger', 'Conmix',
                            'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' )
  
  ##### Bias #####
  bias_median    <- e_median[1]    - beta_true
  bias_mode      <- e_mode[1]      - beta_true
  bias_ivw       <- e_ivw[1]       - beta_true
  bias_pivw      <- e_pivw[1]      - beta_true
  bias_egger     <- e_egger[1]     - beta_true
  bias_conmix    <- e_conmix[1]    - beta_true
  bias_MULTI     <- e_MULTI[1]     - beta_true
  bias_MULTI_0.1 <- e_MULTI_0.1[1] - beta_true
  bias_MULTI_0.3 <- e_MULTI_0.3[1] - beta_true
  bias_MULTI_0.5 <- e_MULTI_0.5[1] - beta_true
  bias        <- c( bias_median, bias_mode, bias_ivw, bias_pivw, bias_egger, bias_conmix,
                    bias_MULTI, bias_MULTI_0.1, bias_MULTI_0.3, bias_MULTI_0.5 )
  names( bias ) <- c( 'Median', 'Mode', 'IVW', 'pIVW', 'Egger', 'Conmix',
                      'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' )
  
  ##### Merge Rate #####
  merge_rate <- paste0( c( tissue_similar_0.1, tissue_similar_0.3, tissue_similar_0.5 ), collapse = " " )
  names( merge_rate ) <- 'Merge_Rate'
  result <- list( typeIerror = typeIerror, bias = bias, merge_rate = merge_rate )
  
  return( result )
  
}, mc.cores = detectCores( ) - 1 )

# typeI <- lapply( sim_res, function( x ) x$typeIerror ) %>%
#           do.call( rbind, . ) %>%
#            as.data.frame( . )

save( sim_res, file = 'result.RData' )

