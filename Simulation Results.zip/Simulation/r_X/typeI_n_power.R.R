library( ggplot2 )
library( gridExtra )
library( grid )
library( ggpubr )
##### Result 1. r_X = 0 #####
mydata1 <- data.frame( 
  data = c( 
    0.850, 0.164, 0.298, 0.462, 0.082, 0.002, 0.002, 0.004, 0.004,
    0.978, 0.792, 0.976, 0.974, 0.328, 0.668, 0.688, 0.724, 0.752,
    1.000, 1.000, 1.000, 1.000, 0.606, 0.910, 0.926, 0.976, 0.988 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)


##### Result 2. r_X = 0.2 #####
mydata2 <- data.frame( 
  data = c( 
    0.816, 0.166, 0.298, 0.462, 0.080, 0.002, 0.002, 0.006, 0.006,
    0.968, 0.786, 0.976, 0.974, 0.336, 0.670, 0.688, 0.724, 0.750,
    0.998, 1.000, 1.000, 1.000, 0.606, 0.908, 0.922, 0.974, 0.986 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)


##### Result 3. r_X = 0.4 #####
mydata3 <- data.frame( 
  data = c( 
    0.846, 0.164, 0.298, 0.462, 0.082, 0.002, 0.002, 0.002, 0.004,
    0.978, 0.786, 0.976, 0.974, 0.340, 0.670, 0.690, 0.726, 0.752,
    1.000, 1.000, 1.000, 1.000, 0.600, 0.908, 0.922, 0.974, 0.986),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)


##### Result 4. r_X = 0.6 #####
mydata4 <- data.frame( 
  data = c( 
    0.846, 0.172, 0.292, 0.450, 0.078, 0.002, 0.002, 0.006, 0.006,
    0.970, 0.776, 0.976, 0.968, 0.302, 0.652, 0.662, 0.720, 0.750,
    1.000, 1.000, 1.000, 1.000, 0.602, 0.908, 0.922, 0.974, 0.986 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 5. r_X = 0.8 #####
mydata5 <- data.frame( 
  data = c( 
    0.814, 0.160, 0.298, 0.460, 0.084, 0.002, 0.002, 0.006, 0.006,
    0.972, 0.784, 0.976, 0.974, 0.336, 0.670, 0.692, 0.730, 0.754,
    1.000, 1.000, 1.000, 1.000, 0.600, 0.908, 0.922, 0.974, 0.986 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 6. r_X = 1 #####
mydata6 <- data.frame( 
  data = c( 
    0.820, 0.168, 0.316, 0.720, 0.056, 0.002, 0.002, 0.002, 0.002,
    0.930, 0.852, 0.980, 0.996, 0.262, 0.694, 0.718, 0.744, 0.786,
    1.000, 1.000, 1.000, 1.000, 0.602, 0.908, 0.922, 0.974, 0.986 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI_s', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

p1 <- ggplot( mydata1, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = expression( h[gamma]^2 ), y = 'Type I error / Power', title = bquote( r[X] == 0 ) ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.3,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p2 <- ggplot( mydata2, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = bquote( r[X] == 0.2 ) ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p3 <- ggplot( mydata3, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = expression( h[gamma]^2 ), y = NULL, title = bquote( r[X] == 0.4 ) ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p4 <- ggplot( mydata4, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = 'Type I error / Power', title = 'r_X= 0.6' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.3,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )
p5 <- ggplot( mydata5, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = expression( h[gamma]^2 ), y = NULL, title = bquote( r[X] == 0.8 ) ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )
p6 <- ggplot( mydata6, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI_s' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'r_X= 1' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

# combined <- ggarrange( p1, p2, p3, p4, p5, p6, align = 'hv', common.legend = T, legend = 'bottom' )
combined <- ggarrange( p1, p3, p5, align = 'hv', common.legend = T, legend = 'bottom', ncol = 3 )
grid.newpage( ); grid.draw( combined )
# # ggsave( '/Volumes/Hide in lab/Yu Cheng/博士课题/Multi-tissue MR/Results/Simulation/r_X/TypeIerror.pdf', plot = combined, width = 14, height = 6 )
