library( ggplot2 )
library( gridExtra )
library( grid )
library( ggpubr )
##### Result 1. nGTEX = 1000; nGWAS = 10000 #####
mydata1 <- data.frame( 
  data = c( 
    0.836, 0.162, 0.278, 0.488, 0.012, 0.002, 0.002, 0.004, 0.004,
    0.978, 0.800, 0.972, 0.976, 0.128, 0.492, 0.526, 0.580, 0.594,
    1.000, 1.000, 1.000, 1.000, 0.308, 0.796, 0.830, 0.902, 0.904 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)
results


##### Result 2. nGTEX = 1000; nGWAS = 50000 #####
mydata2 <- data.frame( 
  data = c( 
    0.848, 0.180, 0.314, 0.644, 0.026, 0.002, 0.002, 0.002, 0.002,
    0.948, 0.804, 0.970, 0.988, 0.086, 0.412, 0.458, 0.466, 0.454,
    0.998, 1.000, 1.000, 1.000, 0.302, 0.786, 0.796, 0.880, 0.884 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)


##### Result 3. nGTEX = 1000; nGWAS = 100000 #####
mydata3 <- data.frame( 
  data = c( 
    0.818, 0.172, 0.284, 0.714, 0.010, 0.002, 0.002, 0.002, 0.004,
    0.934, 0.826, 0.978, 0.984, 0.064, 0.408, 0.448, 0.450, 0.482,
    0.996, 1.000, 1.000, 1.000, 0.210, 0.784, 0.802, 0.876, 0.880 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)


##### Result 4. nGTEX = 5000; nGWAS = 10000 #####
mydata4 <- data.frame( 
  data = c( 
    0.820, 0.190, 0.278, 0.438, 0.010, 0.002, 0.002, 0.002, 0.004,
    0.976, 0.790, 0.964, 0.964, 0.262, 0.656, 0.674, 0.714, 0.742,
    1.000, 1.000, 1.000, 1.000, 0.586, 0.914, 0.938, 0.984, 0.990 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 5. nGTEX = 5000; nGWAS = 50000 #####
mydata5 <- data.frame( 
  data = c( 
    0.834, 0.178, 0.296, 0.652, 0.060, 0.002, 0.002, 0.002, 0.002,
    0.948, 0.836, 0.984, 0.994, 0.236, 0.690, 0.692, 0.744, 0.776,
    0.998, 1.000, 1.000, 1.000, 0.494, 0.922, 0.940, 0.982, 0.986 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 6. nGTEX = 5000; nGWAS = 100000 #####
mydata6 <- data.frame( 
  data = c( 
    0.820, 0.168, 0.316, 0.720, 0.056, 0.002, 0.002, 0.002, 0.002,
    0.930, 0.852, 0.980, 0.996, 0.262, 0.694, 0.718, 0.744, 0.786,
    0.996, 1.000, 1.000, 1.000, 0.526, 0.904, 0.920, 0.970, 0.982 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 7. nGTEX = 10000; nGWAS = 10000 #####
mydata7 <- data.frame( 
  data = c(
    0.850, 0.164, 0.298, 0.462, 0.082, 0.002, 0.004, 0.006, 0.006,
    0.978, 0.978, 0.976, 0.974, 0.328, 0.668, 0.688, 0.724, 0.752,
    1.000, 1.000, 1.000, 1.000, 0.606, 0.910, 0.926, 0.976, 0.988 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)


##### Result 8. nGTEX = 10000; nGWAS = 50000 #####
mydata8 <- data.frame( 
  data = c(
    0.852, 0.204, 0.304, 0.662, 0.112, 0.002, 0.002, 0.002, 0.002,
    0.936, 0.848, 0.978, 0.990, 0.348, 0.722, 0.730, 0.752, 0.778,
    1.000, 1.000, 1.000, 1.000, 0.608, 0.926, 0.942, 0.980, 0.990 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

##### Result 9. nGTEX = 10000; nGWAS = 100000 #####
mydata9 <- data.frame( 
  data = c(
    0.824, 0.184, 0.302, 0.730, 0.110, 0.004, 0.004, 0.004, 0.004,
    0.942, 0.826, 0.982, 0.996, 0.358, 0.706, 0.714, 0.758, 0.798,
    0.998, 1.000, 1.000, 1.000, 0.558, 0.942, 0.952, 0.988, 0.992 ),
  method = factor( 
    rep( c( 'Conmix',	'Egger', 'IVW', 'Median', 'Mode', 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5' ), 6 ), 
    levels = c( 'MULTI', 'MULTI_0.1', 'MULTI_0.3', 'MULTI_0.5', 'IVW', 'Egger', 'Median',	'Mode', 'Conmix' )
  ),
  h2 = factor( c( rep('0', 9), rep('10^-2', 9), rep('10^-1', 9) ),levels = c('0', '10^-2', '10^-1') )
)

p1 <- ggplot( mydata1, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = 'Type I error / Power', title = 'nGTEX = 1000; nGWAS = 10000' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.3,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p2 <- ggplot( mydata2, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nGTEX = 1000; nGWAS = 50000' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p3 <- ggplot( mydata3, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nGTEX = 1000; nGWAS = 100000' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0.5, 1, 0, 1), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p4 <- ggplot( mydata4, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = 'Type I error / Power', title = 'nGTEX = 5000; nGWAS = 10000' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.3,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )
p5 <- ggplot( mydata5, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nGTEX = 5000; nGWAS = 50000' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    legend.position = 'bottom',
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )
p6 <- ggplot( mydata6, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nGTEX = 5000; nGWAS = 100000' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p7 <- ggplot( mydata7, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nGTEX = 10000; nGWAS = 10000' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p8 <- ggplot( mydata7, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nGTEX = 10000; nGWAS = 50000' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

p9 <- ggplot( mydata7, aes( x = h2, y = data, colour = method, group = method ) ) +
  geom_line( aes( linetype = method ), size = 1 ) +
  scale_linetype_manual( values = c( 'MULTI' = 'solid', 'MULTI_0.1' = 'solid', 'MULTI_0.3' = 'solid', 'MULTI_0.5' = 'solid',
                                     'IVW' = 'dotdash', 'Egger' = 'dotdash', 'Median' = 'dotdash', 'Mode' = 'dotdash', 'Conmix' = 'dotdash' ) ) +
  geom_rect(aes(xmin = 0.8, xmax = 1.2, ymin = 0, ymax = 1), fill = '#D6ECFE', alpha = 0.02, color = NA) +
  geom_hline(aes(yintercept = 0.05), linetype = 'dashed', color = 'black', size = 1) +
  geom_hline(aes(yintercept = 0.80), linetype = 'dashed', color = 'black', size = 1) +
  labs( x = '', y = NULL, title = 'nGTEX = 10000; nGWAS = 100000' ) +
  scale_color_manual( values = c( '#F1C4CC', '#DD869E', '#C94457', '#F80600',
                                  '#F2B600', '#F28C50', '#588BAF', '#698C5F', '#7A80C0' ) ) +
  scale_x_discrete( labels = c('0', expression(10^-2), expression(10^-1) ) ) +
  scale_y_continuous( breaks = c(0, 0.05, 0.25, 0.5, 0.75, 0.8, 1), 
                      labels = c('0.00', '0.05', '0.25', '0.50', '0.75', '0.80', '1.00') ) +
  guides( colour = guide_legend(
    nrow = 1,
    override.aes = list(
      linetype = c( 'solid', 'solid', 'solid', 'solid', 'dotdash', 'dotdash', 'dotdash', 'dotdash', 'dotdash' )
    ) ), linetype = 'none' ) +
  theme_bw( ) +
  theme(
    aspect.ratio = 1.25,
    plot.title = element_text(hjust = .5, size = 15),
    panel.grid = element_blank(), 
    panel.border = element_blank(),
    axis.line = element_line(),
    axis.text = element_text(size = 16, color = 'black'),
    axis.title = element_text(size = 18),
    legend.text = element_text(size = 16),
    legend.title = element_blank( ),
    legend.position = 'bottom',
    plot.margin = unit( c( 0, 1, 0.5, 1 ), 'lines' ),
    axis.title.y.left = element_text( margin = margin( r = 15 ) ) )

combined <- ggarrange( p1, p2, p3, p4, p5, p6, p7, p8, p9,
                       align = 'hv', common.legend = T, legend = 'bottom' )
grid.newpage( ); grid.draw( combined )
ggsave( '/Volumes/Hide in lab/Yu Cheng/博士课题/Multi-tissue MR/Results/Simulation/samplesize/TypeIerror.pdf', plot = combined, width = 14, height = 14 )
